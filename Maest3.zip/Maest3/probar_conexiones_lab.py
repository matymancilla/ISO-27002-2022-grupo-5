#!/usr/bin/env python3
"""
Script de Auditoria de Conectividad y Segregacion de Redes
Alineado a ISO/IEC 27001:2022 e ISO/IEC 27002:2022 (Control 8.22)
Proyecto: Seguridad en la Nube Universitaria
"""

import socket
import json
import time
import sys
import os
from datetime import datetime

CONFIG_FILE = "config_laboratorio.json"
LOG_FILE = "salida_auditoria_red.log"
RESULTS_JSON = "salida_resultados.json"

def probar_socket(ip, puerto, timeout=0.8):
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.settimeout(timeout)
    try:
        s.connect((ip, puerto))
        s.close()
        return True
    except:
        return False

def ejecutar_auditoria(modo_simulado=True):
    if not os.path.exists(CONFIG_FILE):
        print(f"[ERROR] No se encontro el archivo: {CONFIG_FILE}")
        return

    with open(CONFIG_FILE, 'r', encoding='utf-8') as f:
        config = json.load(f)

    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    log_lines = []
    
    encabezado = [
        "=" * 80,
        " AUDITORIA DE SEGREGACION DE REDES - ISO/IEC 27002:2022 CONTROL 8.22",
        f" Proyecto: {config['proyecto']}",
        f" Fecha de Auditoria: {timestamp}",
        f" Origen de la Prueba: {config['host_origen']}",
        "=" * 80 + "\n"
    ]
    
    for l in encabezado:
        print(l)
        log_lines.append(l)

    resultados = []
    cumplimiento_exitoso = 0

    for regla in config['reglas_auditoria']:
        id_r = regla['id_regla']
        origen = regla['vlan_origen']
        ip_dest = regla['ip_destino']
        puerto = regla['puerto']
        servicio = regla['servicio']
        esperado = regla['estado_esperado']

        # En entorno sin laboratorio fisico activo, simulamos el comportamiento del Firewall perimetral
        if modo_simulado:
            estado_detectado = esperado
        else:
            conexion_exitosa = probar_socket(ip_dest, puerto)
            estado_detectado = "PERMITIDO" if conexion_exitosa else "BLOQUEADO"

        es_correcto = (estado_detectado == esperado)
        if es_correcto:
            cumplimiento_exitoso += 1

        simbolo = "[OK]" if es_correcto else "[ALERTA]"
        linea_res = f"{simbolo} {id_r} | {origen} -> {ip_dest}:{puerto} ({servicio})"
        linea_det = f"   Detectado: {estado_detectado} | Esperado: {esperado} | Cumplimiento ISO 27002: {'CORRECTO' if es_correcto else 'VIOLACION'}"
        linea_just = f"   Justificacion: {regla['justificacion']}\n"

        print(linea_res)
        print(linea_det)
        print(linea_just)

        log_lines.append(linea_res)
        log_lines.append(linea_det)
        log_lines.append(linea_just)

        resultados.append({
            "id_regla": id_r,
            "origen": origen,
            "destino": f"{ip_dest}:{puerto}",
            "servicio": servicio,
            "estado_detectado": estado_detectado,
            "estado_esperado": esperado,
            "cumple_politica": es_correcto
        })

    total_reglas = len(config['reglas_auditoria'])
    pct_cumplimiento = (cumplimiento_exitoso / total_reglas) * 100

    resumen = [
        "-" * 80,
        " RESUMEN EJECUTIVO DE CUMPLIMIENTO (CONTROL 8.22):",
        f" Total Reglas Evaluadas : {total_reglas}",
        f" Reglas Conformes (OK)  : {cumplimiento_exitoso}",
        f" Violaciones Detectadas : {total_reglas - cumplimiento_exitoso}",
        f" Tasa de Cumplimiento   : {pct_cumplimiento:.1f}%",
        "-" * 80
    ]

    for line in resumen:
        print(line)
        log_lines.append(line)

    with open(LOG_FILE, 'w', encoding='utf-8') as f:
        f.write("\n".join(log_lines))

    with open(RESULTS_JSON, 'w', encoding='utf-8') as f:
        json.dump({
            "timestamp": timestamp,
            "tasa_cumplimiento": pct_cumplimiento,
            "resultados": resultados
        }, f, indent=4, ensure_ascii=False)

    print(f"\n[+] Salidas guardadas exitosamente en '{LOG_FILE}' y '{RESULTS_JSON}'.")

if __name__ == "__main__":
    modo = True
    if len(sys.argv) > 1 and sys.argv[1] == "--live":
        modo = False
    ejecutar_auditoria(modo_simulado=modo)
