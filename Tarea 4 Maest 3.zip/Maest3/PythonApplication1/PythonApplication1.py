import sqlite3
import csv
import re
from datetime import datetime

DB = "universidad.db"

def conectar():
    """Establece conexión con la base de datos local SQLite."""
    return sqlite3.connect(DB)

def inicializar_tabla_eventos():
    """Crea la tabla común de eventos si no existe (NIST SP 800-53 AU-2 / AU-12)."""
    with conectar() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS eventos (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                fecha TEXT NOT NULL,          -- Formato ISO 8601: YYYY-MM-DD HH:MM:SS
                usuario TEXT NOT NULL,
                recurso TEXT NOT NULL,
                tipo_evento TEXT NOT NULL,    -- 'login', 'acceso_recurso', etc.
                resultado TEXT NOT NULL,      -- 'exitoso' o 'fallido'
                detalle TEXT
            );
        """)

def validar_fecha_iso(fecha_str):
    """Valida que la fecha cumpla con el estándar ISO 8601 (YYYY-MM-DD HH:MM:SS)."""
    patron = r"^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$"
    if not re.match(patron, str(fecha_str)):
        return False
    try:
        datetime.strptime(fecha_str, "%Y-%m-%d %H:%M:%S")
        return True
    except ValueError:
        return False

def registrar_evento(fecha, usuario, recurso, tipo_evento, resultado, detalle=""):
    """
    Registra un evento de auditoría validando la integridad de los campos (NIST SP 800-53 AU-3).
    """
    if not fecha or not validar_fecha_iso(fecha):
        raise ValueError("Fecha inválida. Debe usar formato ISO 8601: 'YYYY-MM-DD HH:MM:SS'")
    if not usuario or not str(usuario).strip():
        raise ValueError("El campo 'usuario' no puede estar vacío.")
    if not recurso or not str(recurso).strip():
        raise ValueError("El campo 'recurso' no puede estar vacío.")
    if str(resultado).lower() not in ('exitoso', 'fallido'):
        raise ValueError("El resultado debe ser estrictamente 'exitoso' o 'fallido'.")

    with conectar() as conn:
        conn.execute("""
            INSERT INTO eventos (fecha, usuario, recurso, tipo_evento, resultado, detalle)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (fecha, usuario.strip(), recurso.strip(), tipo_evento.strip(), resultado.lower(), detalle.strip()))

# --- CONSULTAS DE AUDITORÍA ---

def consultar_eventos_por_usuario(usuario):
    """Consulta eventos filtrados por usuario especifico."""
    with conectar() as conn:
        return conn.execute("""
            SELECT id, fecha, usuario, recurso, tipo_evento, resultado, detalle
            FROM eventos
            WHERE usuario = ?
            ORDER BY fecha ASC
        """, (usuario,)).fetchall()

def consultar_eventos_por_periodo(fecha_inicio, fecha_fin):
    """Consulta eventos dentro de un rango temporal en formato ISO."""
    if not validar_fecha_iso(fecha_inicio) or not validar_fecha_iso(fecha_fin):
        raise ValueError("Rango de fechas inválido. Formato requerido: 'YYYY-MM-DD HH:MM:SS'")

    with conectar() as conn:
        return conn.execute("""
            SELECT id, fecha, usuario, recurso, tipo_evento, resultado, detalle
            FROM eventos
            WHERE fecha BETWEEN ? AND ?
            ORDER BY fecha ASC
        """, (fecha_inicio, fecha_fin)).fetchall()

def consultar_eventos_por_resultado(resultado):
    """Consulta eventos según su resultado ('exitoso' o 'fallido')."""
    if resultado.lower() not in ('exitoso', 'fallido'):
        raise ValueError("El resultado debe ser 'exitoso' o 'fallido'.")

    with conectar() as conn:
        return conn.execute("""
            SELECT id, fecha, usuario, recurso, tipo_evento, resultado, detalle
            FROM eventos
            WHERE resultado = ?
            ORDER BY fecha ASC
        """, (resultado.lower(),)).fetchall()

# --- REGLAS DE DETECCIÓN DE ANOMALÍAS ---

def detectar_intentos_fallidos(limite=3):
    """
    Patrón 1: Fuerza Bruta / Múltiples inicios de sesión fallidos (NIST SP 800-53 AU-6).
    """
    with conectar() as conn:
        filas = conn.execute("""
            SELECT usuario, COUNT(*) as cantidad
            FROM eventos
            WHERE tipo_evento = 'login' AND resultado = 'fallido'
            GROUP BY usuario
            HAVING COUNT(*) >= ?
        """, (limite,)).fetchall()

    alertas = []
    for usuario, cantidad in filas:
        alertas.append({
            "usuario": usuario,
            "tipo_alerta": "Posible Fuerza Bruta (Logins Fallidos)",
            "conteo_eventos": cantidad,
            "regla": f"Intentos fallidos de login >= {limite}",
            "prioridad": "Alta"
        })
    return alertas

def detectar_accesos_denegados_sensibles(limite=2):
    """
    Patrón 2: Intentos reiterados de acceso denegado a recursos restringidos/sensibles.
    """
    recursos_sensibles = ('/expedientes/pago', '/admin/servidores', '/matricula/modificar_notas')
    with conectar() as conn:
        filas = conn.execute("""
            SELECT usuario, recurso, COUNT(*) as cantidad
            FROM eventos
            WHERE resultado = 'fallido' AND recurso IN (?, ?, ?)
            GROUP BY usuario, recurso
            HAVING COUNT(*) >= ?
        """, (*recursos_sensibles, limite)).fetchall()

    alertas = []
    for usuario, recurso, cantidad in filas:
        alertas.append({
            "usuario": usuario,
            "tipo_alerta": "Acceso Denegado Reincidente a Recurso Sensible",
            "conteo_eventos": cantidad,
            "regla": f"Accesos fallidos >= {limite} en recurso sensible: {recurso}",
            "prioridad": "Critica"
        })
    return alertas

# --- EXPORTACIÓN DE REPORTES A CSV ---

def exportar_reportes_csv(archivo_alertas="alertas.csv", archivo_eventos="eventos.csv"):
    """Exporta las alertas detectadas y el histórico de eventos a archivos CSV (AU-7)."""
    todas_alertas = detectar_intentos_fallidos(limite=3) + detectar_accesos_denegados_sensibles(limite=2)

    # 1. Exportar alertas.csv
    with open(archivo_alertas, mode="w", newline="", encoding="utf-8") as f_alt:
        writer = csv.DictWriter(f_alt, fieldnames=["usuario", "tipo_alerta", "conteo_eventos", "regla", "prioridad"])
        writer.writeheader()
        writer.writerows(todas_alertas)

    # 2. Exportar eventos.csv
    with conectar() as conn:
        eventos = conn.execute("SELECT id, fecha, usuario, recurso, tipo_evento, resultado, detalle FROM eventos").fetchall()

    with open(archivo_eventos, mode="w", newline="", encoding="utf-8") as f_evt:
        writer = csv.writer(f_evt)
        writer.writerow(["id", "fecha", "usuario", "recurso", "tipo_evento", "resultado", "detalle"])
        writer.writerows(eventos)

    print(f"[+] Archivos de auditoría exportados: '{archivo_alertas}' y '{archivo_eventos}'")

# --- BLOQUE PRINCIPAL DE PRUEBA Y GENERACIÓN DE DATOS FICTICIOS ---

def generar_datos_prueba():
    """Prueba la tabla de eventos con casos de uso normales y anómalos."""
    inicializar_tabla_eventos()
    with conectar() as conn:
        conn.execute("DELETE FROM eventos")  # Limpieza para pruebas limpias

    print("=== 1. REGISTRANDO EVENTOS ===")
    
    # Escenario A: Usuario Legítimo (Comportamiento normal)
    registrar_evento("2026-10-24 08:00:00", "estudiante1", "/lms/curso", "login", "exitoso", "Inicio de sesión correcto")
    registrar_evento("2026-10-24 08:05:00", "estudiante1", "/lms/tarea", "acceso_recurso", "exitoso", "Envío de archivo")

    # Escenario B: Ataque de Fuerza Bruta (4 intentos fallidos de login)
    for i in range(4):
        registrar_evento(f"2026-10-24 09:1{i}:00", "usuario_attacker", "/login", "login", "fallido", "Credenciales incorrectas")

    # Escenario C: Intento de Acceso No Autorizado a Recurso Sensible (2 rechazos)
    registrar_evento("2026-10-24 10:00:00", "empleado_test", "/expedientes/pago", "acceso_recurso", "fallido", "Denegado por política RBAC")
    registrar_evento("2026-10-24 10:01:00", "empleado_test", "/expedientes/pago", "acceso_recurso", "fallido", "Denegado por política RBAC")

if __name__ == "__main__":
    generar_datos_prueba()

    print("\n=== 2. PRUEBA DE CONSULTAS POR FILTRO ===")
    eventos_estudiante = consultar_eventos_por_usuario("estudiante1")
    print(f"Eventos encontrados para 'estudiante1': {len(eventos_estudiante)}")

    eventos_periodo = consultar_eventos_por_periodo("2026-10-24 08:00:00", "2026-10-24 09:30:00")
    print(f"Eventos en periodo 08:00-09:30: {len(eventos_periodo)}")

    eventos_fallidos = consultar_eventos_por_resultado("fallido")
    print(f"Total de eventos fallidos registrados: {len(eventos_fallidos)}")

    print("\n=== 3. EJECUCIÓN DE REGLAS DE DETECCIÓN ===")
    fb_alertas = detectar_intentos_fallidos(limite=3)
    rs_alertas = detectar_accesos_denegados_sensibles(limite=2)

    print(f"Alertas de Fuerza Bruta ({len(fb_alertas)}):")
    for a in fb_alertas:
        print(f"  [!] Usuario: {a['usuario']} | Regla: '{a['regla']}' | Eventos: {a['conteo_eventos']}")

    print(f"\nAlertas de Recurso Sensible ({len(rs_alertas)}):")
    for a in rs_alertas:
        print(f"  [CRÍTICA] Usuario: {a['usuario']} | Regla: '{a['regla']}' | Eventos: {a['conteo_eventos']}")

    print("\n=== 4. PRUEBA DE VALIDACIÓN DE CAMPOS Y MANEJO DE ERRORES ===")
    try:
        registrar_evento("24-10-2026 08:00", "test", "/lms", "login", "exitoso")
    except ValueError as e:
        print(f"[OK] Validación de fecha correcta: {e}")

    print("\n=== 5. EXPORTACIÓN DE REPORTES A CSV ===")
    exportar_reportes_csv()
